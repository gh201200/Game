local #NewLuaScript# = class("#NewLuaScript#")

function #NewLuaScript#:ctor(...)

end

return #NewLuaScript#.new()
