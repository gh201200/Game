﻿using System;
using SLua;
using System.Collections.Generic;
[UnityEngine.Scripting.Preserve]
public class Lua_AssetType : LuaObject {
	static public void reg(IntPtr l) {
		getEnumTable(l,"AssetType");
		addMember(l,0,"Sprite");
		addMember(l,1,"Texture2D");
		addMember(l,2,"TextAsset");
		addMember(l,3,"AudioClip");
		addMember(l,4,"AnimationClip");
		addMember(l,5,"Font");
		addMember(l,6,"Material");
		addMember(l,7,"Prefab");
		addMember(l,8,"Scene");
		addMember(l,9,"None");
		LuaDLL.lua_pop(l, 1);
	}
}
