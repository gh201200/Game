﻿using System;
using SLua;
using System.Collections.Generic;
[UnityEngine.Scripting.Preserve]
public class Lua_Config : LuaObject {
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int constructor(IntPtr l) {
		try {
			Config o;
			o=new Config();
			pushValue(l,true);
			pushValue(l,o);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int get_test(IntPtr l) {
		try {
			pushValue(l,true);
			pushValue(l,Config.test);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int set_test(IntPtr l) {
		try {
			System.Boolean v;
			checkType(l,2,out v);
			Config.test=v;
			pushValue(l,true);
			return 1;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int get_AssetPath(IntPtr l) {
		try {
			pushValue(l,true);
			pushValue(l,Config.AssetPath);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int get_LuaPath(IntPtr l) {
		try {
			pushValue(l,true);
			pushValue(l,Config.LuaPath);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int get_StreamingAssetsPath(IntPtr l) {
		try {
			pushValue(l,true);
			pushValue(l,Config.StreamingAssetsPath);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[UnityEngine.Scripting.Preserve]
	static public void reg(IntPtr l) {
		getTypeTable(l,"Config");
		addMember(l,"test",get_test,set_test,false);
		addMember(l,"AssetPath",get_AssetPath,null,false);
		addMember(l,"LuaPath",get_LuaPath,null,false);
		addMember(l,"StreamingAssetsPath",get_StreamingAssetsPath,null,false);
		createTypeMetatable(l,constructor, typeof(Config));
	}
}
