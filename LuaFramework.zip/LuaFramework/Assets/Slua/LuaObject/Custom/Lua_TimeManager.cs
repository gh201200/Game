﻿using System;
using SLua;
using System.Collections.Generic;
[UnityEngine.Scripting.Preserve]
public class Lua_TimeManager : LuaObject {
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int Add(IntPtr l) {
		try {
			TimeManager self=(TimeManager)checkSelf(l);
			System.Double a1;
			checkType(l,2,out a1);
			System.Action a2;
			checkDelegate(l,3,out a2);
			var ret=self.Add(a1,a2);
			pushValue(l,true);
			pushValue(l,ret);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int AddCycle(IntPtr l) {
		try {
			TimeManager self=(TimeManager)checkSelf(l);
			System.Double a1;
			checkType(l,2,out a1);
			System.Double a2;
			checkType(l,3,out a2);
			System.Action a3;
			checkDelegate(l,4,out a3);
			var ret=self.AddCycle(a1,a2,a3);
			pushValue(l,true);
			pushValue(l,ret);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int Delete(IntPtr l) {
		try {
			TimeManager self=(TimeManager)checkSelf(l);
			System.Int32 a1;
			checkType(l,2,out a1);
			self.Delete(a1);
			pushValue(l,true);
			return 1;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int DeleteAll(IntPtr l) {
		try {
			TimeManager self=(TimeManager)checkSelf(l);
			self.DeleteAll();
			pushValue(l,true);
			return 1;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int get_Instance(IntPtr l) {
		try {
			pushValue(l,true);
			pushValue(l,TimeManager.Instance);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[UnityEngine.Scripting.Preserve]
	static public void reg(IntPtr l) {
		getTypeTable(l,"TimeManager");
		addMember(l,Add);
		addMember(l,AddCycle);
		addMember(l,Delete);
		addMember(l,DeleteAll);
		addMember(l,"Instance",get_Instance,null,false);
		createTypeMetatable(l,null, typeof(TimeManager),typeof(UnityEngine.MonoBehaviour));
	}
}
