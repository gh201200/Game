﻿using System;
using SLua;
using System.Collections.Generic;
[UnityEngine.Scripting.Preserve]
public class Lua_System_IO_FileInfo : LuaObject {
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int constructor(IntPtr l) {
		try {
			System.IO.FileInfo o;
			System.String a1;
			checkType(l,2,out a1);
			o=new System.IO.FileInfo(a1);
			pushValue(l,true);
			pushValue(l,o);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int Encrypt(IntPtr l) {
		try {
			System.IO.FileInfo self=(System.IO.FileInfo)checkSelf(l);
			self.Encrypt();
			pushValue(l,true);
			return 1;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int Decrypt(IntPtr l) {
		try {
			System.IO.FileInfo self=(System.IO.FileInfo)checkSelf(l);
			self.Decrypt();
			pushValue(l,true);
			return 1;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int OpenText(IntPtr l) {
		try {
			System.IO.FileInfo self=(System.IO.FileInfo)checkSelf(l);
			var ret=self.OpenText();
			pushValue(l,true);
			pushValue(l,ret);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int CreateText(IntPtr l) {
		try {
			System.IO.FileInfo self=(System.IO.FileInfo)checkSelf(l);
			var ret=self.CreateText();
			pushValue(l,true);
			pushValue(l,ret);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int AppendText(IntPtr l) {
		try {
			System.IO.FileInfo self=(System.IO.FileInfo)checkSelf(l);
			var ret=self.AppendText();
			pushValue(l,true);
			pushValue(l,ret);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int Create(IntPtr l) {
		try {
			System.IO.FileInfo self=(System.IO.FileInfo)checkSelf(l);
			var ret=self.Create();
			pushValue(l,true);
			pushValue(l,ret);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int OpenRead(IntPtr l) {
		try {
			System.IO.FileInfo self=(System.IO.FileInfo)checkSelf(l);
			var ret=self.OpenRead();
			pushValue(l,true);
			pushValue(l,ret);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int OpenWrite(IntPtr l) {
		try {
			System.IO.FileInfo self=(System.IO.FileInfo)checkSelf(l);
			var ret=self.OpenWrite();
			pushValue(l,true);
			pushValue(l,ret);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int Open(IntPtr l) {
		try {
			int argc = LuaDLL.lua_gettop(l);
			if(argc==2){
				System.IO.FileInfo self=(System.IO.FileInfo)checkSelf(l);
				System.IO.FileMode a1;
				checkEnum(l,2,out a1);
				var ret=self.Open(a1);
				pushValue(l,true);
				pushValue(l,ret);
				return 2;
			}
			else if(argc==3){
				System.IO.FileInfo self=(System.IO.FileInfo)checkSelf(l);
				System.IO.FileMode a1;
				checkEnum(l,2,out a1);
				System.IO.FileAccess a2;
				checkEnum(l,3,out a2);
				var ret=self.Open(a1,a2);
				pushValue(l,true);
				pushValue(l,ret);
				return 2;
			}
			else if(argc==4){
				System.IO.FileInfo self=(System.IO.FileInfo)checkSelf(l);
				System.IO.FileMode a1;
				checkEnum(l,2,out a1);
				System.IO.FileAccess a2;
				checkEnum(l,3,out a2);
				System.IO.FileShare a3;
				checkEnum(l,4,out a3);
				var ret=self.Open(a1,a2,a3);
				pushValue(l,true);
				pushValue(l,ret);
				return 2;
			}
			pushValue(l,false);
			LuaDLL.lua_pushstring(l,"No matched override function Open to call");
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int Delete(IntPtr l) {
		try {
			System.IO.FileInfo self=(System.IO.FileInfo)checkSelf(l);
			self.Delete();
			pushValue(l,true);
			return 1;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int MoveTo(IntPtr l) {
		try {
			System.IO.FileInfo self=(System.IO.FileInfo)checkSelf(l);
			System.String a1;
			checkType(l,2,out a1);
			self.MoveTo(a1);
			pushValue(l,true);
			return 1;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int Replace(IntPtr l) {
		try {
			int argc = LuaDLL.lua_gettop(l);
			if(argc==3){
				System.IO.FileInfo self=(System.IO.FileInfo)checkSelf(l);
				System.String a1;
				checkType(l,2,out a1);
				System.String a2;
				checkType(l,3,out a2);
				var ret=self.Replace(a1,a2);
				pushValue(l,true);
				pushValue(l,ret);
				return 2;
			}
			else if(argc==4){
				System.IO.FileInfo self=(System.IO.FileInfo)checkSelf(l);
				System.String a1;
				checkType(l,2,out a1);
				System.String a2;
				checkType(l,3,out a2);
				System.Boolean a3;
				checkType(l,4,out a3);
				var ret=self.Replace(a1,a2,a3);
				pushValue(l,true);
				pushValue(l,ret);
				return 2;
			}
			pushValue(l,false);
			LuaDLL.lua_pushstring(l,"No matched override function Replace to call");
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int get_Exists(IntPtr l) {
		try {
			System.IO.FileInfo self=(System.IO.FileInfo)checkSelf(l);
			pushValue(l,true);
			pushValue(l,self.Exists);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int get_Name(IntPtr l) {
		try {
			System.IO.FileInfo self=(System.IO.FileInfo)checkSelf(l);
			pushValue(l,true);
			pushValue(l,self.Name);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int get_IsReadOnly(IntPtr l) {
		try {
			System.IO.FileInfo self=(System.IO.FileInfo)checkSelf(l);
			pushValue(l,true);
			pushValue(l,self.IsReadOnly);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int set_IsReadOnly(IntPtr l) {
		try {
			System.IO.FileInfo self=(System.IO.FileInfo)checkSelf(l);
			bool v;
			checkType(l,2,out v);
			self.IsReadOnly=v;
			pushValue(l,true);
			return 1;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int get_Length(IntPtr l) {
		try {
			System.IO.FileInfo self=(System.IO.FileInfo)checkSelf(l);
			pushValue(l,true);
			pushValue(l,self.Length);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int get_DirectoryName(IntPtr l) {
		try {
			System.IO.FileInfo self=(System.IO.FileInfo)checkSelf(l);
			pushValue(l,true);
			pushValue(l,self.DirectoryName);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int get_Directory(IntPtr l) {
		try {
			System.IO.FileInfo self=(System.IO.FileInfo)checkSelf(l);
			pushValue(l,true);
			pushValue(l,self.Directory);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[UnityEngine.Scripting.Preserve]
	static public void reg(IntPtr l) {
		getTypeTable(l,"System.IO.FileInfo");
		addMember(l,Encrypt);
		addMember(l,Decrypt);
		addMember(l,OpenText);
		addMember(l,CreateText);
		addMember(l,AppendText);
		addMember(l,Create);
		addMember(l,OpenRead);
		addMember(l,OpenWrite);
		addMember(l,Open);
		addMember(l,Delete);
		addMember(l,MoveTo);
		addMember(l,Replace);
		addMember(l,"Exists",get_Exists,null,true);
		addMember(l,"Name",get_Name,null,true);
		addMember(l,"IsReadOnly",get_IsReadOnly,set_IsReadOnly,true);
		addMember(l,"Length",get_Length,null,true);
		addMember(l,"DirectoryName",get_DirectoryName,null,true);
		addMember(l,"Directory",get_Directory,null,true);
		createTypeMetatable(l,constructor, typeof(System.IO.FileInfo),typeof(System.IO.FileSystemInfo));
	}
}
