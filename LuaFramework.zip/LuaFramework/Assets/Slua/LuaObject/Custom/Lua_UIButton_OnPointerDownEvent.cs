﻿using System;
using SLua;
using System.Collections.Generic;
[UnityEngine.Scripting.Preserve]
public class Lua_UIButton_OnPointerDownEvent : LuaObject {
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int constructor(IntPtr l) {
		try {
			UIButton.OnPointerDownEvent o;
			o=new UIButton.OnPointerDownEvent();
			pushValue(l,true);
			pushValue(l,o);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[UnityEngine.Scripting.Preserve]
	static public void reg(IntPtr l) {
		LuaUnityEvent_UnityEngine_EventSystems_PointerEventData.reg(l);
		getTypeTable(l,"UIButton.OnPointerDownEvent");
		createTypeMetatable(l,constructor, typeof(UIButton.OnPointerDownEvent),typeof(LuaUnityEvent_UnityEngine_EventSystems_PointerEventData));
	}
}
