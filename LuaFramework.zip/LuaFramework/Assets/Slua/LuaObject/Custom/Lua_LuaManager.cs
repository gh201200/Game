﻿using System;
using SLua;
using System.Collections.Generic;
[UnityEngine.Scripting.Preserve]
public class Lua_LuaManager : LuaObject {
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int DoFile(IntPtr l) {
		try {
			LuaManager self=(LuaManager)checkSelf(l);
			System.String a1;
			checkType(l,2,out a1);
			var ret=self.DoFile(a1);
			pushValue(l,true);
			pushValue(l,ret);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int DoString(IntPtr l) {
		try {
			LuaManager self=(LuaManager)checkSelf(l);
			System.String a1;
			checkType(l,2,out a1);
			var ret=self.DoString(a1);
			pushValue(l,true);
			pushValue(l,ret);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int DoBuffer(IntPtr l) {
		try {
			LuaManager self=(LuaManager)checkSelf(l);
			System.Byte[] a1;
			checkArray(l,2,out a1);
			System.String a2;
			checkType(l,3,out a2);
			var ret=self.DoBuffer(a1,a2);
			pushValue(l,true);
			pushValue(l,ret);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int GetLuaFunction(IntPtr l) {
		try {
			LuaManager self=(LuaManager)checkSelf(l);
			System.String a1;
			checkType(l,2,out a1);
			var ret=self.GetLuaFunction(a1);
			pushValue(l,true);
			pushValue(l,ret);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int CallLuaFunction(IntPtr l) {
		try {
			LuaManager self=(LuaManager)checkSelf(l);
			System.String a1;
			checkType(l,2,out a1);
			System.Object[] a2;
			checkParams(l,3,out a2);
			var ret=self.CallLuaFunction(a1,a2);
			pushValue(l,true);
			pushValue(l,ret);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int Init(IntPtr l) {
		try {
			LuaManager self=(LuaManager)checkSelf(l);
			System.Action<System.Int32> a1;
			checkDelegate(l,2,out a1);
			System.Action<LuaManager> a2;
			checkDelegate(l,3,out a2);
			self.Init(a1,a2);
			pushValue(l,true);
			return 1;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int Clear(IntPtr l) {
		try {
			LuaManager self=(LuaManager)checkSelf(l);
			self.Clear();
			pushValue(l,true);
			return 1;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int get_luaSvr(IntPtr l) {
		try {
			LuaManager self=(LuaManager)checkSelf(l);
			pushValue(l,true);
			pushValue(l,self.luaSvr);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int set_luaSvr(IntPtr l) {
		try {
			LuaManager self=(LuaManager)checkSelf(l);
			SLua.LuaSvr v;
			checkType(l,2,out v);
			self.luaSvr=v;
			pushValue(l,true);
			return 1;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int get_luaState(IntPtr l) {
		try {
			LuaManager self=(LuaManager)checkSelf(l);
			pushValue(l,true);
			pushValue(l,self.luaState);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int set_luaState(IntPtr l) {
		try {
			LuaManager self=(LuaManager)checkSelf(l);
			SLua.LuaState v;
			checkType(l,2,out v);
			self.luaState=v;
			pushValue(l,true);
			return 1;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int set_OnUpdateEvent(IntPtr l) {
		try {
			System.Action v;
			int op=checkDelegate(l,2,out v);
			if(op==0) LuaManager.OnUpdateEvent=v;
			else if(op==1) LuaManager.OnUpdateEvent+=v;
			else if(op==2) LuaManager.OnUpdateEvent-=v;
			pushValue(l,true);
			return 1;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int set_OnFixedUpdateEvent(IntPtr l) {
		try {
			System.Action v;
			int op=checkDelegate(l,2,out v);
			if(op==0) LuaManager.OnFixedUpdateEvent=v;
			else if(op==1) LuaManager.OnFixedUpdateEvent+=v;
			else if(op==2) LuaManager.OnFixedUpdateEvent-=v;
			pushValue(l,true);
			return 1;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int set_OnLateUpdateEvent(IntPtr l) {
		try {
			System.Action v;
			int op=checkDelegate(l,2,out v);
			if(op==0) LuaManager.OnLateUpdateEvent=v;
			else if(op==1) LuaManager.OnLateUpdateEvent+=v;
			else if(op==2) LuaManager.OnLateUpdateEvent-=v;
			pushValue(l,true);
			return 1;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int set_OnDestroyEvent(IntPtr l) {
		try {
			System.Action v;
			int op=checkDelegate(l,2,out v);
			if(op==0) LuaManager.OnDestroyEvent=v;
			else if(op==1) LuaManager.OnDestroyEvent+=v;
			else if(op==2) LuaManager.OnDestroyEvent-=v;
			pushValue(l,true);
			return 1;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int get_Instance(IntPtr l) {
		try {
			pushValue(l,true);
			pushValue(l,LuaManager.Instance);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int getItem(IntPtr l) {
		try {
			LuaManager self=(LuaManager)checkSelf(l);
			string v;
			checkType(l,2,out v);
			var ret = self[v];
			pushValue(l,true);
			pushValue(l,ret);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int setItem(IntPtr l) {
		try {
			LuaManager self=(LuaManager)checkSelf(l);
			string v;
			checkType(l,2,out v);
			System.Object c;
			checkType(l,3,out c);
			self[v]=c;
			pushValue(l,true);
			return 1;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[UnityEngine.Scripting.Preserve]
	static public void reg(IntPtr l) {
		getTypeTable(l,"LuaManager");
		addMember(l,DoFile);
		addMember(l,DoString);
		addMember(l,DoBuffer);
		addMember(l,GetLuaFunction);
		addMember(l,CallLuaFunction);
		addMember(l,Init);
		addMember(l,Clear);
		addMember(l,getItem);
		addMember(l,setItem);
		addMember(l,"luaSvr",get_luaSvr,set_luaSvr,true);
		addMember(l,"luaState",get_luaState,set_luaState,true);
		addMember(l,"OnUpdateEvent",null,set_OnUpdateEvent,false);
		addMember(l,"OnFixedUpdateEvent",null,set_OnFixedUpdateEvent,false);
		addMember(l,"OnLateUpdateEvent",null,set_OnLateUpdateEvent,false);
		addMember(l,"OnDestroyEvent",null,set_OnDestroyEvent,false);
		addMember(l,"Instance",get_Instance,null,false);
		createTypeMetatable(l,null, typeof(LuaManager),typeof(UnityEngine.MonoBehaviour));
	}
}
