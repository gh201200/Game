﻿using System;
using SLua;
using System.Collections.Generic;
[UnityEngine.Scripting.Preserve]
public class Lua_AssetLoader : LuaObject {
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int Clear(IntPtr l) {
		try {
			AssetLoader self=(AssetLoader)checkSelf(l);
			self.Clear();
			pushValue(l,true);
			return 1;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int LoadAsync(IntPtr l) {
		try {
			int argc = LuaDLL.lua_gettop(l);
			if(argc==4){
				AssetLoader self=(AssetLoader)checkSelf(l);
				System.String a1;
				checkType(l,2,out a1);
				AssetType a2;
				checkEnum(l,3,out a2);
				System.Action<System.Object> a3;
				checkDelegate(l,4,out a3);
				self.LoadAsync(a1,a2,a3);
				pushValue(l,true);
				return 1;
			}
			else if(argc==5){
				AssetLoader self=(AssetLoader)checkSelf(l);
				System.String a1;
				checkType(l,2,out a1);
				AssetType a2;
				checkEnum(l,3,out a2);
				System.Action<System.Object> a3;
				checkDelegate(l,4,out a3);
				System.Action<System.Double> a4;
				checkDelegate(l,5,out a4);
				self.LoadAsync(a1,a2,a3,a4);
				pushValue(l,true);
				return 1;
			}
			pushValue(l,false);
			LuaDLL.lua_pushstring(l,"No matched override function LoadAsync to call");
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int Load(IntPtr l) {
		try {
			AssetLoader self=(AssetLoader)checkSelf(l);
			System.String a1;
			checkType(l,2,out a1);
			AssetType a2;
			checkEnum(l,3,out a2);
			var ret=self.Load(a1,a2);
			pushValue(l,true);
			pushValue(l,ret);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int get_Progress(IntPtr l) {
		try {
			AssetLoader self=(AssetLoader)checkSelf(l);
			pushValue(l,true);
			pushValue(l,self.Progress);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int get_CurLoad(IntPtr l) {
		try {
			AssetLoader self=(AssetLoader)checkSelf(l);
			pushValue(l,true);
			pushValue(l,self.CurLoad);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int get_Instance(IntPtr l) {
		try {
			pushValue(l,true);
			pushValue(l,AssetLoader.Instance);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int get_Manifest(IntPtr l) {
		try {
			AssetLoader self=(AssetLoader)checkSelf(l);
			pushValue(l,true);
			pushValue(l,self.Manifest);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[UnityEngine.Scripting.Preserve]
	static public void reg(IntPtr l) {
		getTypeTable(l,"AssetLoader");
		addMember(l,Clear);
		addMember(l,LoadAsync);
		addMember(l,Load);
		addMember(l,"Progress",get_Progress,null,true);
		addMember(l,"CurLoad",get_CurLoad,null,true);
		addMember(l,"Instance",get_Instance,null,false);
		addMember(l,"Manifest",get_Manifest,null,true);
		createTypeMetatable(l,null, typeof(AssetLoader),typeof(UnityEngine.MonoBehaviour));
	}
}
