﻿using System;
using SLua;
using System.Collections.Generic;
[UnityEngine.Scripting.Preserve]
public class Lua_HttpHelper : LuaObject {
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int DownLoadFile(IntPtr l) {
		try {
			HttpHelper self=(HttpHelper)checkSelf(l);
			System.String a1;
			checkType(l,2,out a1);
			System.String a2;
			checkType(l,3,out a2);
			System.Action<System.Int64,System.Int64> a3;
			checkDelegate(l,4,out a3);
			System.Action a4;
			checkDelegate(l,5,out a4);
			self.DownLoadFile(a1,a2,a3,a4);
			pushValue(l,true);
			return 1;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int DownLoadFileAsync(IntPtr l) {
		try {
			HttpHelper self=(HttpHelper)checkSelf(l);
			System.String a1;
			checkType(l,2,out a1);
			System.String a2;
			checkType(l,3,out a2);
			var ret=self.DownLoadFileAsync(a1,a2);
			pushValue(l,true);
			pushValue(l,ret);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int UploadFile(IntPtr l) {
		try {
			HttpHelper self=(HttpHelper)checkSelf(l);
			System.String a1;
			checkType(l,2,out a1);
			System.String a2;
			checkType(l,3,out a2);
			System.Action<System.Single,System.Single> a3;
			checkDelegate(l,4,out a3);
			System.Action a4;
			checkDelegate(l,5,out a4);
			self.UploadFile(a1,a2,a3,a4);
			pushValue(l,true);
			return 1;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int GetRemoteHTTPFileSize_s(IntPtr l) {
		try {
			System.String a1;
			checkType(l,1,out a1);
			var ret=HttpHelper.GetRemoteHTTPFileSize(a1);
			pushValue(l,true);
			pushValue(l,ret);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int get_Instance(IntPtr l) {
		try {
			pushValue(l,true);
			pushValue(l,HttpHelper.Instance);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[UnityEngine.Scripting.Preserve]
	static public void reg(IntPtr l) {
		getTypeTable(l,"HttpHelper");
		addMember(l,DownLoadFile);
		addMember(l,DownLoadFileAsync);
		addMember(l,UploadFile);
		addMember(l,GetRemoteHTTPFileSize_s);
		addMember(l,"Instance",get_Instance,null,false);
		createTypeMetatable(l,null, typeof(HttpHelper),typeof(UnityEngine.MonoBehaviour));
	}
}
