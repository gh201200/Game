﻿using System;
using SLua;
using System.Collections.Generic;
[UnityEngine.Scripting.Preserve]
public class Lua_AsyncArgs : LuaObject {
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int constructor(IntPtr l) {
		try {
			AsyncArgs o;
			o=new AsyncArgs();
			pushValue(l,true);
			pushValue(l,o);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int get_cur(IntPtr l) {
		try {
			AsyncArgs self=(AsyncArgs)checkSelf(l);
			pushValue(l,true);
			pushValue(l,self.cur);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int set_cur(IntPtr l) {
		try {
			AsyncArgs self=(AsyncArgs)checkSelf(l);
			System.Int64 v;
			checkType(l,2,out v);
			self.cur=v;
			pushValue(l,true);
			return 1;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int get_total(IntPtr l) {
		try {
			AsyncArgs self=(AsyncArgs)checkSelf(l);
			pushValue(l,true);
			pushValue(l,self.total);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int set_total(IntPtr l) {
		try {
			AsyncArgs self=(AsyncArgs)checkSelf(l);
			System.Int64 v;
			checkType(l,2,out v);
			self.total=v;
			pushValue(l,true);
			return 1;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int get_progress(IntPtr l) {
		try {
			AsyncArgs self=(AsyncArgs)checkSelf(l);
			pushValue(l,true);
			pushValue(l,self.progress);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int set_progress(IntPtr l) {
		try {
			AsyncArgs self=(AsyncArgs)checkSelf(l);
			System.Double v;
			checkType(l,2,out v);
			self.progress=v;
			pushValue(l,true);
			return 1;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int get_isDone(IntPtr l) {
		try {
			AsyncArgs self=(AsyncArgs)checkSelf(l);
			pushValue(l,true);
			pushValue(l,self.isDone);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int set_isDone(IntPtr l) {
		try {
			AsyncArgs self=(AsyncArgs)checkSelf(l);
			System.Boolean v;
			checkType(l,2,out v);
			self.isDone=v;
			pushValue(l,true);
			return 1;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int get_arg(IntPtr l) {
		try {
			AsyncArgs self=(AsyncArgs)checkSelf(l);
			pushValue(l,true);
			pushValue(l,self.arg);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int set_arg(IntPtr l) {
		try {
			AsyncArgs self=(AsyncArgs)checkSelf(l);
			System.Object v;
			checkType(l,2,out v);
			self.arg=v;
			pushValue(l,true);
			return 1;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[UnityEngine.Scripting.Preserve]
	static public void reg(IntPtr l) {
		getTypeTable(l,"AsyncArgs");
		addMember(l,"cur",get_cur,set_cur,true);
		addMember(l,"total",get_total,set_total,true);
		addMember(l,"progress",get_progress,set_progress,true);
		addMember(l,"isDone",get_isDone,set_isDone,true);
		addMember(l,"arg",get_arg,set_arg,true);
		createTypeMetatable(l,constructor, typeof(AsyncArgs));
	}
}
