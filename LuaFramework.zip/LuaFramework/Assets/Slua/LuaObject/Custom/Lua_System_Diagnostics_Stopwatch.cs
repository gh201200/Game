﻿using System;
using SLua;
using System.Collections.Generic;
[UnityEngine.Scripting.Preserve]
public class Lua_System_Diagnostics_Stopwatch : LuaObject {
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int constructor(IntPtr l) {
		try {
			System.Diagnostics.Stopwatch o;
			o=new System.Diagnostics.Stopwatch();
			pushValue(l,true);
			pushValue(l,o);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int Reset(IntPtr l) {
		try {
			System.Diagnostics.Stopwatch self=(System.Diagnostics.Stopwatch)checkSelf(l);
			self.Reset();
			pushValue(l,true);
			return 1;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int Start(IntPtr l) {
		try {
			System.Diagnostics.Stopwatch self=(System.Diagnostics.Stopwatch)checkSelf(l);
			self.Start();
			pushValue(l,true);
			return 1;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int Stop(IntPtr l) {
		try {
			System.Diagnostics.Stopwatch self=(System.Diagnostics.Stopwatch)checkSelf(l);
			self.Stop();
			pushValue(l,true);
			return 1;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int GetTimestamp_s(IntPtr l) {
		try {
			var ret=System.Diagnostics.Stopwatch.GetTimestamp();
			pushValue(l,true);
			pushValue(l,ret);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int StartNew_s(IntPtr l) {
		try {
			var ret=System.Diagnostics.Stopwatch.StartNew();
			pushValue(l,true);
			pushValue(l,ret);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int get_Frequency(IntPtr l) {
		try {
			pushValue(l,true);
			pushValue(l,System.Diagnostics.Stopwatch.Frequency);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int get_IsHighResolution(IntPtr l) {
		try {
			pushValue(l,true);
			pushValue(l,System.Diagnostics.Stopwatch.IsHighResolution);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int get_Elapsed(IntPtr l) {
		try {
			System.Diagnostics.Stopwatch self=(System.Diagnostics.Stopwatch)checkSelf(l);
			pushValue(l,true);
			pushValue(l,self.Elapsed);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int get_ElapsedMilliseconds(IntPtr l) {
		try {
			System.Diagnostics.Stopwatch self=(System.Diagnostics.Stopwatch)checkSelf(l);
			pushValue(l,true);
			pushValue(l,self.ElapsedMilliseconds);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int get_ElapsedTicks(IntPtr l) {
		try {
			System.Diagnostics.Stopwatch self=(System.Diagnostics.Stopwatch)checkSelf(l);
			pushValue(l,true);
			pushValue(l,self.ElapsedTicks);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int get_IsRunning(IntPtr l) {
		try {
			System.Diagnostics.Stopwatch self=(System.Diagnostics.Stopwatch)checkSelf(l);
			pushValue(l,true);
			pushValue(l,self.IsRunning);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[UnityEngine.Scripting.Preserve]
	static public void reg(IntPtr l) {
		getTypeTable(l,"System.Diagnostics.Stopwatch");
		addMember(l,Reset);
		addMember(l,Start);
		addMember(l,Stop);
		addMember(l,GetTimestamp_s);
		addMember(l,StartNew_s);
		addMember(l,"Frequency",get_Frequency,null,false);
		addMember(l,"IsHighResolution",get_IsHighResolution,null,false);
		addMember(l,"Elapsed",get_Elapsed,null,true);
		addMember(l,"ElapsedMilliseconds",get_ElapsedMilliseconds,null,true);
		addMember(l,"ElapsedTicks",get_ElapsedTicks,null,true);
		addMember(l,"IsRunning",get_IsRunning,null,true);
		createTypeMetatable(l,constructor, typeof(System.Diagnostics.Stopwatch));
	}
}
