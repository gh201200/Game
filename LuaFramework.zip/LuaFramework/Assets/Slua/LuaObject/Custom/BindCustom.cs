﻿using System;
using System.Collections.Generic;
namespace SLua {
	[LuaBinder(3)]
	public class BindCustom {
		public static Action<IntPtr>[] GetBindList() {
			Action<IntPtr>[] list= {
				Lua_Api.reg,
				Lua_AssetType.reg,
				Lua_AssetLoader.reg,
				Lua_Config.reg,
				Lua_EncryptUtil.reg,
				Lua_EventListener.reg,
				Lua_GameUtil.reg,
				Lua_AsyncArgs.reg,
				Lua_HttpHelper.reg,
				Lua_LuaManager.reg,
				Lua_TimeManager.reg,
				Lua_UIButton.reg,
				Lua_UIButton_OnPointerDownEvent.reg,
				Lua_UIButton_OnPointerUpEvent.reg,
				Lua_UIButton_OnPointerEnterEvent.reg,
				Lua_UIButton_OnPointerExitEvent.reg,
				Lua_UIButton_OnPointerClickEvent.reg,
				Lua_UIButton_OnPointerDropEvent.reg,
				Lua_ZipUtil.reg,
				Lua_Custom.reg,
				Lua_foostruct.reg,
				Lua_FloatEvent.reg,
				Lua_ListViewEvent.reg,
				Lua_SLuaTest.reg,
				Lua_System_Collections_Generic_List_1_int.reg,
				Lua_XXList.reg,
				Lua_AbsClass.reg,
				Lua_HelloWorld.reg,
				Lua_NewCoroutine.reg,
				Lua_System_Collections_Generic_Dictionary_2_int_string.reg,
				Lua_System_String.reg,
				Lua_System_Diagnostics_Stopwatch.reg,
				Lua_System_IO_File.reg,
				Lua_System_IO_FileInfo.reg,
				Lua_System_IO_Directory.reg,
				Lua_System_IO_DirectoryInfo.reg,
			};
			return list;
		}
	}
}
