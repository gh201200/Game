﻿using System;
using SLua;
using System.Collections.Generic;
[UnityEngine.Scripting.Preserve]
public class Lua_UnityEngine_Joint2D : LuaObject {
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int GetReactionForce(IntPtr l) {
		try {
			UnityEngine.Joint2D self=(UnityEngine.Joint2D)checkSelf(l);
			System.Single a1;
			checkType(l,2,out a1);
			var ret=self.GetReactionForce(a1);
			pushValue(l,true);
			pushValue(l,ret);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int GetReactionTorque(IntPtr l) {
		try {
			UnityEngine.Joint2D self=(UnityEngine.Joint2D)checkSelf(l);
			System.Single a1;
			checkType(l,2,out a1);
			var ret=self.GetReactionTorque(a1);
			pushValue(l,true);
			pushValue(l,ret);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int get_connectedBody(IntPtr l) {
		try {
			UnityEngine.Joint2D self=(UnityEngine.Joint2D)checkSelf(l);
			pushValue(l,true);
			pushValue(l,self.connectedBody);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int set_connectedBody(IntPtr l) {
		try {
			UnityEngine.Joint2D self=(UnityEngine.Joint2D)checkSelf(l);
			UnityEngine.Rigidbody2D v;
			checkType(l,2,out v);
			self.connectedBody=v;
			pushValue(l,true);
			return 1;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int get_enableCollision(IntPtr l) {
		try {
			UnityEngine.Joint2D self=(UnityEngine.Joint2D)checkSelf(l);
			pushValue(l,true);
			pushValue(l,self.enableCollision);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int set_enableCollision(IntPtr l) {
		try {
			UnityEngine.Joint2D self=(UnityEngine.Joint2D)checkSelf(l);
			bool v;
			checkType(l,2,out v);
			self.enableCollision=v;
			pushValue(l,true);
			return 1;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int get_breakForce(IntPtr l) {
		try {
			UnityEngine.Joint2D self=(UnityEngine.Joint2D)checkSelf(l);
			pushValue(l,true);
			pushValue(l,self.breakForce);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int set_breakForce(IntPtr l) {
		try {
			UnityEngine.Joint2D self=(UnityEngine.Joint2D)checkSelf(l);
			float v;
			checkType(l,2,out v);
			self.breakForce=v;
			pushValue(l,true);
			return 1;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int get_breakTorque(IntPtr l) {
		try {
			UnityEngine.Joint2D self=(UnityEngine.Joint2D)checkSelf(l);
			pushValue(l,true);
			pushValue(l,self.breakTorque);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int set_breakTorque(IntPtr l) {
		try {
			UnityEngine.Joint2D self=(UnityEngine.Joint2D)checkSelf(l);
			float v;
			checkType(l,2,out v);
			self.breakTorque=v;
			pushValue(l,true);
			return 1;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int get_reactionForce(IntPtr l) {
		try {
			UnityEngine.Joint2D self=(UnityEngine.Joint2D)checkSelf(l);
			pushValue(l,true);
			pushValue(l,self.reactionForce);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	[UnityEngine.Scripting.Preserve]
	static public int get_reactionTorque(IntPtr l) {
		try {
			UnityEngine.Joint2D self=(UnityEngine.Joint2D)checkSelf(l);
			pushValue(l,true);
			pushValue(l,self.reactionTorque);
			return 2;
		}
		catch(Exception e) {
			return error(l,e);
		}
	}
	[UnityEngine.Scripting.Preserve]
	static public void reg(IntPtr l) {
		getTypeTable(l,"UnityEngine.Joint2D");
		addMember(l,GetReactionForce);
		addMember(l,GetReactionTorque);
		addMember(l,"connectedBody",get_connectedBody,set_connectedBody,true);
		addMember(l,"enableCollision",get_enableCollision,set_enableCollision,true);
		addMember(l,"breakForce",get_breakForce,set_breakForce,true);
		addMember(l,"breakTorque",get_breakTorque,set_breakTorque,true);
		addMember(l,"reactionForce",get_reactionForce,null,true);
		addMember(l,"reactionTorque",get_reactionTorque,null,true);
		createTypeMetatable(l,null, typeof(UnityEngine.Joint2D),typeof(UnityEngine.Behaviour));
	}
}
